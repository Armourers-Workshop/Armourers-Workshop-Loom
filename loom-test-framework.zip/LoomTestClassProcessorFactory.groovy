package moe.plushie.armourers_workshop.loom.impl

import org.gradle.api.internal.tasks.testing.TestClassProcessor
import org.gradle.api.internal.tasks.testing.WorkerTestClassProcessorFactory
import org.gradle.api.internal.tasks.testing.junitplatform.JUnitPlatformSpec
import org.gradle.internal.actor.ActorFactory
import org.gradle.internal.id.IdGenerator
import org.gradle.internal.time.Clock

class LoomTestClassProcessorFactory implements WorkerTestClassProcessorFactory, Serializable {
    private final JUnitPlatformSpec spec

    LoomTestClassProcessorFactory(JUnitPlatformSpec spec) {
        this.spec = spec
    }

    @Override
    TestClassProcessor create(IdGenerator<?> idGenerator, ActorFactory actorFactory, Clock clock) {
        return new LoomTestClassProcessor(this.spec, idGenerator, actorFactory, clock);
    }
}
