package moe.plushie.armourers_workshop.loom.impl

import org.gradle.api.Action
import org.gradle.api.JavaVersion
import org.gradle.api.internal.tasks.testing.TestFramework
import org.gradle.api.internal.tasks.testing.TestFrameworkDistributionModule
import org.gradle.api.internal.tasks.testing.WorkerTestClassProcessorFactory
import org.gradle.api.internal.tasks.testing.detection.TestFrameworkDetector
import org.gradle.api.internal.tasks.testing.filter.DefaultTestFilter
import org.gradle.api.internal.tasks.testing.junitplatform.JUnitPlatformSpec
import org.gradle.api.logging.Logger
import org.gradle.api.logging.Logging
import org.gradle.api.provider.Provider
import org.gradle.api.tasks.testing.TestFilter
import org.gradle.api.tasks.testing.junitplatform.JUnitPlatformOptions
import org.gradle.internal.jvm.UnsupportedJavaRuntimeException
import org.gradle.process.internal.worker.WorkerProcessBuilder

import java.util.regex.Pattern
import java.util.stream.Collectors

class LoomTestFramework implements TestFramework {
    private static final Logger LOGGER = Logging.getLogger(LoomTestFramework.class)
    private static final List<TestFrameworkDistributionModule> DISTRIBUTION_MODULES = List.of(
            new TestFrameworkDistributionModule("junit-platform-engine", Pattern.compile("junit-platform-engine-1.*\\.jar"), "org.gradle.internal.impldep.org.junit.platform.engine.DiscoverySelector"),
            new TestFrameworkDistributionModule("junit-platform-launcher", Pattern.compile("junit-platform-launcher-1.*\\.jar"), "org.gradle.internal.impldep.org.junit.platform.launcher.core.LauncherDiscoveryRequestBuilder"),
            new TestFrameworkDistributionModule("junit-platform-commons", Pattern.compile("junit-platform-commons-1.*\\.jar"), "org.gradle.internal.impldep.org.junit.platform.commons.util.ReflectionUtils")
    )
    private final JUnitPlatformOptions options
    private final DefaultTestFilter filter
    private final boolean useImplementationDependencies
    private final Provider<Boolean> dryRun

    LoomTestFramework(DefaultTestFilter filter, boolean useImplementationDependencies, Provider<Boolean> dryRun) {
        this(filter, useImplementationDependencies, new JUnitPlatformOptions(), dryRun)
    }

    private LoomTestFramework(DefaultTestFilter filter, boolean useImplementationDependencies, JUnitPlatformOptions options, Provider<Boolean> dryRun) {
        this.filter = filter
        this.useImplementationDependencies = useImplementationDependencies
        this.options = options
        this.dryRun = dryRun
    }

    @Override
    TestFramework copyWithFilters(TestFilter newTestFilters) {
        var copiedOptions = new JUnitPlatformOptions()
        copiedOptions.copyFrom(options)
        return new LoomTestFramework(newTestFilters as DefaultTestFilter, useImplementationDependencies, copiedOptions, dryRun)
    }

    @Override
    WorkerTestClassProcessorFactory getProcessorFactory() {
        if (!JavaVersion.current().isJava8Compatible()) {
            throw new UnsupportedJavaRuntimeException("Running JUnit Platform requires Java 8+, please configure your test java executable with Java 8 or higher.");
        }
        validateOptions()
        var spec = new JUnitPlatformSpec(filter.toSpec(), options.getIncludeEngines(), options.getExcludeEngines(), options.getIncludeTags(), options.getExcludeTags(), dryRun.get())
        return new LoomTestClassProcessorFactory(spec)
    }

    @Override
    Action<WorkerProcessBuilder> getWorkerConfigurationAction() {
//        return (builder) -> builder.sharedPackages("org.gradle.internal.impldep.org.junit")
//        return (builder) -> builder.sharedPackages("org.gradle.internal.impldep.org.testng")
        return (builder) -> builder.sharedPackages("org.gradle.internal.impldep.org.junit").sharedPackages("moe.plushie.armourers_workshop.loom.impl").applicationClasspath(List.of(new File(this.class.protectionDomain.codeSource.location.path)))
    }

    @Override
    List<TestFrameworkDistributionModule> getWorkerApplicationModulepathModules() {
        return DISTRIBUTION_MODULES
    }

    @Override
    boolean getUseDistributionDependencies() {
        return useImplementationDependencies
    }

    @Override
    JUnitPlatformOptions getOptions() {
        return options
    }

    @Override
    TestFrameworkDetector getDetector() {
        return null
    }

    @Override
    void close() throws IOException {
    }

    private void validateOptions() {
        Set<String> intersection = new HashSet<>(options.getIncludeTags())
        intersection.retainAll(options.getExcludeTags())
        if (intersection.isEmpty()) {
            return
        }
        if (intersection.size() == 1) {
            LOGGER.warn("The tag '" + (String) intersection.iterator().next() + "' is both included and excluded.  This will result in the tag being excluded, which may not be what was intended.  Please either include or exclude the tag but not both.")
        } else {
            String allTags = (String) intersection.stream().sorted().map((s) -> "'" + s + "'").collect(Collectors.joining(", "))
            LOGGER.warn("The tags " + allTags + " are both included and excluded.  This will result in the tags being excluded, which may not be what was intended.  Please either include or exclude the tags but not both.")
        }
    }
}
