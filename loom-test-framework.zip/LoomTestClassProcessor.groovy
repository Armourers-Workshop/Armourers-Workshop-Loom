package moe.plushie.armourers_workshop.loom.impl

import org.gradle.api.Action
import org.gradle.api.internal.tasks.testing.TestClassProcessor
import org.gradle.api.internal.tasks.testing.TestClassRunInfo
import org.gradle.api.internal.tasks.testing.TestResultProcessor
import org.gradle.api.internal.tasks.testing.filter.TestFilterSpec
import org.gradle.api.internal.tasks.testing.filter.TestSelectionMatcher
import org.gradle.api.internal.tasks.testing.junit.JUnitTestClassExecutor
import org.gradle.api.internal.tasks.testing.junitplatform.JUnitPlatformSpec
import org.gradle.api.internal.tasks.testing.junitplatform.JUnitPlatformTestExecutionListener
import org.gradle.internal.UncheckedException
import org.gradle.internal.actor.Actor
import org.gradle.internal.actor.ActorFactory
import org.gradle.internal.id.IdGenerator
import org.gradle.internal.impldep.org.junit.platform.engine.*
import org.gradle.internal.impldep.org.junit.platform.engine.discovery.DiscoverySelectors
import org.gradle.internal.impldep.org.junit.platform.engine.support.descriptor.ClassSource
import org.gradle.internal.impldep.org.junit.platform.engine.support.descriptor.MethodSource
import org.gradle.internal.impldep.org.junit.platform.launcher.*
import org.gradle.internal.impldep.org.junit.platform.launcher.core.LauncherDiscoveryRequestBuilder
import org.gradle.internal.impldep.org.junit.platform.launcher.core.LauncherFactory
import org.gradle.internal.time.Clock
import org.slf4j.Logger
import org.slf4j.LoggerFactory

import javax.annotation.Nonnull
import javax.annotation.WillCloseWhenClosed
import java.lang.reflect.Modifier
import java.util.stream.Collectors

class LoomTestClassProcessor implements TestClassProcessor {

    private static final Logger LOGGER = LoggerFactory.getLogger(LoomTestClassProcessor.class);
    private final ActorFactory actorFactory
    private Actor resultProcessorActor
    private Action<String> executor

    private final JUnitPlatformSpec spec
    private final IdGenerator<?> idGenerator
    private final Clock clock
    private CollectAllTestClassesExecutor testClassExecutor
    private BackwardsCompatibleLauncherSession launcherSession
    private ClassLoader junitClassLoader

    LoomTestClassProcessor(JUnitPlatformSpec spec, IdGenerator<?> idGenerator, ActorFactory actorFactory, Clock clock) {
        this.actorFactory = actorFactory
        this.spec = spec
        this.idGenerator = idGenerator
        this.clock = clock
    }


    @Override
    void startProcessing(TestResultProcessor resultProcessor) {
        this.resultProcessorActor = actorFactory.createBlockingActor(resultProcessor)
        this.executor = createTestExecutor(resultProcessorActor)
    }

    protected Action<String> createTestExecutor(Actor resultProcessorActor) {
        var threadSafeResultProcessor = (TestResultProcessor) resultProcessorActor.getProxy(TestResultProcessor.class)
        this.launcherSession = BackwardsCompatibleLauncherSession.open()
        this.junitClassLoader = Thread.currentThread().getContextClassLoader()
        this.testClassExecutor = new CollectAllTestClassesExecutor(threadSafeResultProcessor)
        return this.testClassExecutor;
    }

    @Override
    void processTestClass(TestClassRunInfo testClass) {
        LOGGER.debug("Executing test class {}", testClass.getTestClassName())
        this.executor.execute(testClass.getTestClassName())
    }

    @Override
    void stop() {
        this.testClassExecutor.processAllTestClasses()
        this.launcherSession.close()
        this.resultProcessorActor.stop()
    }

    @Override
    void stopNow() {
        throw new UnsupportedOperationException("stopNow() should not be invoked on remote worker TestClassProcessor")
    }


    private void executeDryRun(TestPlan testPlan, TestExecutionListener listener) {
        listener.testPlanExecutionStarted(testPlan);

        for (TestIdentifier root : testPlan.getRoots()) {
            this.dryRun(root, testPlan, listener);
        }

        listener.testPlanExecutionFinished(testPlan);
    }

    private void dryRun(TestIdentifier testIdentifier, TestPlan testPlan, TestExecutionListener listener) {
        if (testIdentifier.isTest()) {
            listener.executionSkipped(testIdentifier, "Gradle test execution dry run");
        } else {
            listener.executionStarted(testIdentifier);

            for (TestIdentifier child : testPlan.getChildren(testIdentifier)) {
                this.dryRun(child, testPlan, listener);
            }

            listener.executionFinished(testIdentifier, TestExecutionResult.successful());
        }

    }

    private boolean supportsVintageTests() {
        try {
            Class.forName("org.gradle.internal.impldep.org.junit.vintage.engine.VintageTestEngine", false, this.junitClassLoader);
            Class.forName("org.gradle.internal.impldep.org.junit.runner.Request", false, this.junitClassLoader);
            return true;
        } catch (ClassNotFoundException var2) {
            return false;
        }
    }

    private boolean isInnerClass(Class<?> klass) {
        return klass.getEnclosingClass() != null && !Modifier.isStatic(klass.getModifiers());
    }

    private Class<?> loadClass(String className) {
        try {
            return Class.forName(className, false, this.junitClassLoader);
        } catch (ClassNotFoundException e) {
            throw UncheckedException.throwAsUncheckedException(e);
        }
    }

    private LauncherDiscoveryRequest createLauncherDiscoveryRequest(List<Class<?>> testClasses) {
        List<DiscoverySelector> classSelectors = (List) testClasses.stream().map(DiscoverySelectors::selectClass).collect(Collectors.toList());
        LauncherDiscoveryRequestBuilder requestBuilder = LauncherDiscoveryRequestBuilder.request().selectors(classSelectors);
        this.addTestNameFilters(requestBuilder);
        this.addEnginesFilter(requestBuilder);
        this.addTagsFilter(requestBuilder);
        return requestBuilder.build();
    }

    private void addEnginesFilter(LauncherDiscoveryRequestBuilder requestBuilder) {
        List<String> includeEngines = this.spec.getIncludeEngines();
        if (!includeEngines.isEmpty()) {
            requestBuilder.filters(new Filter[]{EngineFilter.includeEngines(includeEngines)});
        }

        List<String> excludeEngines = this.spec.getExcludeEngines();
        if (!excludeEngines.isEmpty()) {
            requestBuilder.filters(new Filter[]{EngineFilter.excludeEngines(excludeEngines)});
        }

    }

    private void addTagsFilter(LauncherDiscoveryRequestBuilder requestBuilder) {
        List<String> includeTags = this.spec.getIncludeTags();
        if (!includeTags.isEmpty()) {
            requestBuilder.filters(new Filter[]{TagFilter.includeTags(includeTags)});
        }

        List<String> excludeTags = this.spec.getExcludeTags();
        if (!excludeTags.isEmpty()) {
            requestBuilder.filters(new Filter[]{TagFilter.excludeTags(excludeTags)});
        }

    }

    private void addTestNameFilters(LauncherDiscoveryRequestBuilder requestBuilder) {
        var filter = this.spec.getFilter()
        if (isNotEmpty(filter)) {
            var matcher = new TestSelectionMatcher(filter)
            requestBuilder.filters(new ClassMethodNameFilter(matcher))
        }

    }

    private static boolean isNotEmpty(TestFilterSpec filter) {
        return !filter.getIncludedTests().isEmpty() || !filter.getIncludedTestsCommandLine().isEmpty() || !filter.getExcludedTests().isEmpty();
    }

    private class CollectAllTestClassesExecutor implements Action<String> {
        private final List<Class<?>> testClasses = new ArrayList();
        private final TestResultProcessor resultProcessor;

        CollectAllTestClassesExecutor(TestResultProcessor resultProcessor) {
            this.resultProcessor = resultProcessor;
        }

        @Override
        void execute(@Nonnull String testClassName) {
            Class<?> klass = LoomTestClassProcessor.this.loadClass(testClassName);
            if (!LoomTestClassProcessor.this.isInnerClass(klass) && (!LoomTestClassProcessor.this.supportsVintageTests() || !JUnitTestClassExecutor.isNestedClassInsideEnclosedRunner(klass))) {
                this.testClasses.add(klass);
            }
        }

        private void processAllTestClasses() {
            var discoveryRequest = LoomTestClassProcessor.this.createLauncherDiscoveryRequest(this.testClasses);
            var executionListener = new JUnitPlatformTestExecutionListener(this.resultProcessor, LoomTestClassProcessor.this.clock, LoomTestClassProcessor.this.idGenerator);
            var launcher = LoomTestClassProcessor.this.launcherSession.getLauncher();
            if (LoomTestClassProcessor.this.spec.isDryRun()) {
                var testPlan = launcher.discover(discoveryRequest);
                LoomTestClassProcessor.this.executeDryRun(testPlan, executionListener);
            } else {
                launcher.execute(discoveryRequest, new TestExecutionListener[]{executionListener});
            }
        }
    }

    private static class ClassMethodNameFilter implements PostDiscoveryFilter {
        private final TestSelectionMatcher matcher;

        private ClassMethodNameFilter(TestSelectionMatcher matcher) {
            this.matcher = matcher;
        }

        @Override
        FilterResult apply(TestDescriptor descriptor) {
            return this.classMatch(descriptor) ? FilterResult.included("Class match") : FilterResult.includedIf(this.shouldRun(descriptor), () -> "Method or class match", () -> "Method or class mismatch");
        }

        private boolean shouldRun(TestDescriptor descriptor) {
            return this.shouldRun(descriptor, false);
        }

        private boolean shouldRun(TestDescriptor descriptor, boolean checkingParent) {
            Optional<TestSource> source = descriptor.getSource();
            if (!source.isPresent()) {
                return true;
            } else {
                TestSource testSource = (TestSource) source.get();
                if (testSource instanceof MethodSource) {
                    return this.shouldRun(descriptor, (MethodSource) testSource);
                } else if (testSource instanceof ClassSource) {
                    return this.shouldRun(descriptor, checkingParent, (ClassSource) testSource);
                } else {
                    Optional<TestDescriptor> parent = descriptor.getParent();
                    return parent.isPresent() && this.shouldRun((TestDescriptor) parent.get(), true);
                }
            }
        }

        private boolean shouldRun(TestDescriptor descriptor, boolean checkingParent, ClassSource classSource) {
            Set<? extends TestDescriptor> children = descriptor.getChildren();
            if (!checkingParent) {
                for (TestDescriptor child : children) {
                    if (this.shouldRun(child)) {
                        return true;
                    }
                }
            }

            if (!children.isEmpty()) {
                return true;
            } else {
                String className = classSource.getClassName();
                return this.matcher.matchesTest(className, (String) null) || this.matcher.matchesTest(className, descriptor.getLegacyReportingName());
            }
        }

        private boolean shouldRun(TestDescriptor descriptor, MethodSource methodSource) {
            String methodName = methodSource.getMethodName();
            return this.matcher.matchesTest(methodSource.getClassName(), methodName) || this.matchesParentMethod(descriptor, methodName);
        }

        private boolean matchesParentMethod(TestDescriptor descriptor, String methodName) {
            return descriptor.getParent().flatMap(this::className).filter((className) -> this.matcher.matchesTest(className, methodName)).isPresent();
        }

        private boolean classMatch(TestDescriptor descriptor) {
            while (true) {
                Optional<TestDescriptor> parent = descriptor.getParent();
                if (!parent.isPresent()) {
                    return false;
                }

                if (this.className(descriptor).filter((className) -> this.matcher.matchesTest(className, (String) null)).isPresent()) {
                    return true;
                }

                descriptor = (TestDescriptor) parent.get();
            }
        }

        private Optional<String> className(TestDescriptor descriptor) {
            Optional var10000 = descriptor.getSource();
            Objects.requireNonNull(ClassSource.class);
            var10000 = var10000.filter(ClassSource.class::isInstance);
            Objects.requireNonNull(ClassSource.class);
            return var10000.map(ClassSource.class::cast).map(ClassSource::getClassName);
        }
    }

    private static class BackwardsCompatibleLauncherSession implements AutoCloseable {
        private final Launcher launcher
        private final Runnable onClose

        static BackwardsCompatibleLauncherSession open() {
            try {
                LauncherSession launcherSession = LauncherFactory.openSession();
                return new BackwardsCompatibleLauncherSession(launcherSession);
            } catch (NoSuchMethodError var1) {
                return new BackwardsCompatibleLauncherSession(LauncherFactory.create(), () -> {
                });
            }
        }

        BackwardsCompatibleLauncherSession(@WillCloseWhenClosed LauncherSession session) {
            Launcher var10001 = session.getLauncher();
            this.launcher = var10001;
            this.onClose = session::close;
        }

        BackwardsCompatibleLauncherSession(Launcher launcher, Runnable onClose) {
            this.launcher = launcher;
            this.onClose = onClose;
        }

        Launcher getLauncher() {
            return this.launcher
        }

        @Override
        void close() {
            this.onClose.run()
        }
    }
}
